﻿using UnityEngine;
using System.Collections;

public enum LERP_TYPE
{
	NORMAL = 0,
	EASE_OUT,
	EASE_IN,
	EXPONENTIAL,
	SMOOTHSTEP,
	PLUSSMOOTHSTEP,
}

public class LerpTeste : MonoBehaviour
{
	public LERP_TYPE lerpType = LERP_TYPE.NORMAL;

	public Material _material = null;

	private bool m_canLerp = false;

	private float m_lerp = 0.0f;

	public Color corOne = new Color(1.0f, 0.0f, 0.0f, 1.0f);
	public Color corTwo = new Color(0.0f, 0.0f, 1.0f, 1.0f);

	private Vector3 init = new Vector3(-7.0f, 0.0f, 0.0f);
	private Vector3 end = new Vector3(7.0f, 0.0f, 0.0f);

	private void Start ()
	{
		init.y = transform.position.y;
		end.y = transform.position.y;
	}

	private void Update ()
	{
		if(Input.GetKeyDown(KeyCode.A))
		{
			m_canLerp = true;
		}

		if(Input.GetKeyDown(KeyCode.R))
		{
			m_canLerp = false;
			m_lerp = 0.0f;
			transform.position = init;
		}

		if(m_canLerp && m_lerp < 1.0f)
		{
			m_lerp += Time.deltaTime;

			transform.position = LerpManager.BounceEaseIn(init, end, m_lerp);

			_material.color = LerpManager.BounceEaseIn(corOne, corTwo, m_lerp);

			/*

			switch(lerpType)
			{
				case LERP_TYPE.NORMAL:
					transform.position = Vector3.Lerp(init, end, m_lerp);
					break;

				case LERP_TYPE.EASE_OUT:
					transform.position = LerpManager.EaseOutLerp(init, end, m_lerp);
					break;

				case LERP_TYPE.EASE_IN:
					transform.position = LerpManager.EaseInLerp(init, end, m_lerp);
					break;

				case LERP_TYPE.EXPONENTIAL:
					transform.position = LerpManager.ExponentialLerp(init, end, m_lerp);
					break;

				case LERP_TYPE.SMOOTHSTEP:
					transform.position = LerpManager.SmoothstepLerp(init, end, m_lerp);
					break;

				case LERP_TYPE.PLUSSMOOTHSTEP:
					transform.position = LerpManager.PlusSmoothstepLerp(init, end, m_lerp);
					break;
			}
			*/
		}
	}
}
