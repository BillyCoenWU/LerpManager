﻿using UnityEngine;

//TODO
// All Easing Types Maths
//
// Create Methods To:
// - Color
// - Vector2
// - Vector3
// - Vector4
// - Quaternion
//
// Lerps Types:
// - Lerp
// - Slerp
// - SmoothDamp
//
// Create Necessary Enums
//
// Create Necessary Behaviours
//
// Be Possible Choose beetwen Lerp and LerpUnclamped
//
// Create System Parecido com o iTween

public enum FINAL_ACTION
{
	NONE = 0,

	DEACTIVATE,
	DESTRUCTION
}

public static class LerpManager
{
	#region Constantes

	private const float TWO_PI = Mathf.PI * 2.0f;
	private const float HALF_PI = Mathf.PI / 2.0f;

	#endregion

	#region Mathfs

//	public

	private static float Linear (float t)
	{
		return t*t;
	}

	private static bool m_hasStarted = false;

	private static float m_startValue = 0.0f;
	private static float m_changeInValue = 0.0f;
	private static float m_duration = 1.0f;

	// current time = t
	// start Value = b
	// change In Value = c
	// duration = d

	public static float Exponencial (float t)
	{
		return t;
	}

	public static float SmoothStep (float t)
	{
		return (t*t) * (3.0f - (2.0f * t));
	}

	public static float PlusSmoothStep (float t)
	{
		return (t*t*t) * (t * ((6.0f * t) - 15.0f) + 10.0f);
	}

	private static float QuadraticEaseIn (float t)
	{
		if(!m_hasStarted)
		{
			m_startValue = t;
			m_hasStarted = true;
		}

		m_changeInValue = t - m_startValue;

		return m_changeInValue * t / m_duration + m_startValue;
	}

	public static float BounceEaseIn (float t)
	{
		if(!m_hasStarted)
		{
			m_startValue = t;
			m_hasStarted = true;
		}

		m_changeInValue = t - m_startValue;

		return m_changeInValue - EaseOut(m_duration-t, 0, m_changeInValue, m_duration) + m_startValue;
	}

	public static float EaseOut(float t, float b, float c, float d)
	{
		if ((t/=d) < (1.0f/2.75f))
		{
			return c*(7.5625f*t*t) + b;
		}
		else if (t < (2.0f/2.75f))
		{
			return c*(7.5625f*(t-=(1.5f/2.75f))*t + 0.75f) + b;
		}
		else if (t < (2.5f/2.75f))
		{
			return c*(7.5625f*(t-=(2.25f/2.75f))*t + 0.9375f) + b;
		}
		else
		{
			return c*(7.5625f*(t-=(2.625f/2.75f))*t + 0.984375f) + b;
		}
	}

	#endregion

	#region Color

	public static Color BounceEaseIn (Color a, Color b, float t)
	{
		return Color.LerpUnclamped(a, b, BounceEaseIn(t));
	}

	#endregion

	#region Vector3

	public static Vector3 LinearLerp (Vector3 a, Vector3 b, float t)
	{
		return Vector3.LerpUnclamped(a, b, t);
	}

	public static Vector3 QuadraticEaseIn (Vector3 a, Vector3 b, float t)
	{
		return Vector3.LerpUnclamped(a, b, QuadraticEaseIn(t));
	}

	public static Vector3 BounceEaseIn (Vector3 a, Vector3 b, float t)
	{
		return Vector3.LerpUnclamped(a, b, BounceEaseIn(t));
	}

	//Old
	/*
	public static Vector3 EaseOutLerp (Vector3 a, Vector3 b, float t)
	{
		t = Mathf.Sin(t * Mathf.PI * 0.5f);

		return Vector3.LerpUnclamped(a, b, t);
	}

	public static Vector3 EaseInLerp (Vector3 a, Vector3 b, float t)
	{
		t = 1.0f - Mathf.Cos(t * Mathf.PI * 0.5f);

		return Vector3.LerpUnclamped(a, b, t);
	}

	public static Vector3 ExponentialLerp (Vector3 a, Vector3 b, float t)
	{
		t = t*t;

		return Vector3.LerpUnclamped(a, b, t);
	}

	public static Vector3 SmoothStepLerp (Vector3 a, Vector3 b, float t)
	{
		t = (t*t) * (3.0f - (2.0f * t));

		return Vector3.LerpUnclamped(a, b, t);
	}

	public static Vector3 PlusSmoothStepLerp (Vector3 a, Vector3 b, float t)
	{
		t = (t*t*t) * (t * ((6.0f * t) - 15.0f) + 10.0f);

		return Vector3.LerpUnclamped(a, b, t);
	}

	*/

	#endregion

	#region Vector2

	public static Vector2 EaseOutLerp (Vector2 a, Vector2 b, float t)
	{
		t = Mathf.Sin(t * Mathf.PI * 0.5f);

		return Vector2.Lerp(a, b, t);
	}

	public static Vector2 EaseInLerp (Vector2 a, Vector2 b, float t)
	{
		t = 1.0f - Mathf.Cos(t * Mathf.PI * 0.5f);

		return Vector2.Lerp(a, b, t);
	}

	public static Vector3 ExponentialLerp (Vector2 a, Vector2 b, float t)
	{
		t = t*t;

		return Vector2.Lerp(a, b, t);
	}

	public static Vector2 SmoothstepLerp (Vector2 a, Vector2 b, float t)
	{
		t = (t*t) * (3.0f - (2.0f * t));

		return Vector2.Lerp(a, b, t);
	}

	public static Vector2 PlusSmoothstepLerp (Vector2 a, Vector2 b, float t)
	{
		t = (t*t*t) * (t * ((6.0f * t) - 15.0f) + 10.0f);

		return Vector2.Lerp(a, b, t);
	}

	#endregion
}
